const pills = document.querySelectorAll(".pills");
const contents = document.querySelectorAll(".content");

// pills.forEach((pill,index) => {
//     pill.addEventListener("click",() => {
//         pills.forEach(p => p.classList.remove('active'))
//         contents.forEach(c => c.classList.remove('show'))
//         pill.classList.add('active')
//         contents[index].classList.add('show')
//     })
// })

pills.forEach((pill) => {
  pill.addEventListener("hover", () => {
    const dataPills = pill.getAttribute("data-pills");
    const content = document.getElementById(`content-${dataPills}`);

    pills.forEach((p) => p.classList.remove("active"));
    contents.forEach((c) => c.classList.remove("show"));
    pill.classList.add("active");
    content.classList.add("show");
  });
});
